//
//  MemorizeApp.swift
//  Memorize
//
//  Created by achiraya on 17/10/2566 BE.
//

import SwiftUI

@main
struct MemorizeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
